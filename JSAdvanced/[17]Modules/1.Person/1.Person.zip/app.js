let Person = require('./person').Person;    // with module.exports = {Person}
result.Person = Person;