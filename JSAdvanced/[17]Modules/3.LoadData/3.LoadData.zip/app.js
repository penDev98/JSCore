let dataFunctions = require('./data-functions');
let sort = dataFunctions.sort;
let filter = dataFunctions.filter;


result.sort = sort;
result.filter = filter;